#include <Windows.h>
#include <TlHelp32.h>
#include <iostream>
using namespace std;
MODULEENTRY32 GetModule(DWORD dwProcID,const wchar_t* moduleName)
{
	MODULEENTRY32 modEntry = { 0 };

	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, dwProcID);

	if (hSnapshot != INVALID_HANDLE_VALUE)
	{
		MODULEENTRY32 curr = { 0 };

		curr.dwSize = sizeof(MODULEENTRY32);
		if (Module32First(hSnapshot, &curr))
		{
			do
			{
				if (!wcscmp(curr.szModule, moduleName))
				{
					modEntry = curr;
					break;
				}
			} while (Module32Next(hSnapshot, &curr));
		}
		CloseHandle(hSnapshot);
	}
	return modEntry;
}

DWORD PatternScan(char* base, size_t size, const char* pattern, const char* mask)
{
	size_t patternLength = strlen(mask);

	for (unsigned int i = 0; i < size - patternLength; i++)
	{
		bool found = true;
		for (unsigned int j = 0; j < patternLength; j++)
		{
			if (mask[j] != '?' && pattern[j] != *(base + i + j))
			{
				found = false;
				break;
			}
		}
		if (found)
		{
			return (DWORD)(base + i);
		}
	}
	return 0;
}

DWORD PatternScanEx(HANDLE hProcess, uintptr_t begin, uintptr_t end, const char* pattern, const char* mask)
{
	uintptr_t currentChunk = begin;
	SIZE_T bytesRead;

	while (currentChunk < end)
	{
		char buffer[4096];

		DWORD oldprotect;
		VirtualProtectEx(hProcess, (void*)currentChunk, sizeof(buffer), PAGE_EXECUTE_READWRITE, &oldprotect);
		ReadProcessMemory(hProcess, (void*)currentChunk, &buffer, sizeof(buffer), &bytesRead);
		VirtualProtectEx(hProcess, (void*)currentChunk, sizeof(buffer), oldprotect, &oldprotect);

		if (bytesRead == 0)
		{
			return 0;
		}

		DWORD internalAddress = PatternScan((char*)&buffer, bytesRead, pattern, mask);
		if (internalAddress != 0)
		{
			uintptr_t offsetFromBuffer = (uintptr_t)internalAddress - (uintptr_t)&buffer;// e�er internal adresse bir de�er atand�ysa
			return (DWORD)(currentChunk + offsetFromBuffer);//�uanki adreste,desenin bulundu yerdeki uzakl��� ekleyip adresi d�nd�r�yoruz.
		}
		else
		{
			currentChunk = currentChunk + bytesRead;
		}
	}
	return 0;
}

DWORD PatternScanExModule(HANDLE hProcess, DWORD pid, const wchar_t* module, const char* pattern,  const char* mask)
{
	MODULEENTRY32 modEntry = GetModule(pid, module);

	if (!modEntry.th32ModuleID)
	{
		return 0;
	}

	uintptr_t begin = (uintptr_t)modEntry.modBaseAddr;
	uintptr_t end = begin + modEntry.modBaseSize;
	return PatternScanEx(hProcess, begin, end, pattern, mask);
}
