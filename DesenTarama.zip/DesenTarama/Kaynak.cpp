#include "tool.h"


int main()
{
	HWND hwnd = FindWindowA(0, "AssaultCube");
	DWORD pid;
	GetWindowThreadProcessId(hwnd, &pid);
	HANDLE handle = OpenProcess(PROCESS_ALL_ACCESS, false, pid);
	DWORD adres = PatternScanExModule(handle, pid, L"ac_client.exe","\xff\x08\x8d\x44\x24\x1c\x50\x51\x8b\xce","xxxxxxxxxx");
	//FF 08 8D 44 24 1C 50 51 8B CE
	cout << "Adres:" << adres << endl;
	system("pause");
}